# Saoukaba — SK MIDEK

Projet React/Vite prêt pour publication gratuite sur Vercel.

## Publication rapide
1. Crée un compte GitHub.
2. Crée un nouveau repository.
3. Ajoute ces fichiers dans le repository.
4. Ouvre Vercel.
5. Clique sur Add New Project.
6. Importe le repository GitHub.
7. Clique sur Deploy.

## À modifier avant publication
- Numéro WhatsApp dans `src/App.jsx` : `whatsappNumber`
- Numéro CCP
- Coordonnées de contact
- Adresse email
